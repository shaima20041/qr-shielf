درع QR | QR Shield — Bilingual QR phishing awareness website
============================================================

Files:
- index.html: complete responsive Arabic/English awareness website.

Features:
- Illustrations embedded as inline SVG/CSS (no external image requests required).
- Sections on QR phishing risks, fake stickers, information theft, warning signs, and safer habits.
- Interactive quiz with local feedback.
- Arabic/English language toggle.
- No password or personal-data collection, no camera access, no screenshot capture, no quiz-answer transmission, no analytics or cookies in the page.

To publish for phones:
1. Upload index.html to a static HTTPS hosting provider you control, such as GitHub Pages.
2. Test the published URL on a phone in both languages.
3. Generate a QR code from the exact public HTTPS URL.
4. Scan-test the QR code on a second device before distributing it.

Note: Hosting providers may independently process ordinary connection logs. Follow your institution's approval and privacy policies.
